Program XYZWIN was written by
  Craig.Larrimore@noaa.gov

Program XYZWIN calls functions writted by
  Dr. Mark Schenewerk (NGS retired)

The main functions to consider are
   plh2xyz() - converts Lat,Lon, Ellip to XYZ
   xyz2plh() - converts XYZ to Lat,Lon,Ellip.

File 'screen.txt' shows a sample run of
Dr. Schenewerk's program  'xyz2llh'
and three files 'run1.csh', 'run2.csh', 'run3.csh'
show the various input.

The executable 'xyz2llh' is not provided.
(NGS has xyz2llh on a SUN Unix system)

The source code for XYZWIN windows is not provided
by can be on request.
