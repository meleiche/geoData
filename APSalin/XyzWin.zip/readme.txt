                            National Geodetic Survey
                                    XyzWin


  XyzWin is a PC Windows program for converting NAD83 Latitude and Longitude
  to earth centered XYZ values on the GRS80 ellipsoid and vice versa.

  From the Main Window, click the 'Help' menu button for more information.



  Problems?, contact:
  -------------------
    Craig Larrimore
    EMail = Craig.Larrimore@noaa.gov
    Phone = (301) 713-3257 x152
